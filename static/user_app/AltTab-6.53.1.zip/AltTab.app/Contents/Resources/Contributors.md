# Contributors

They helped [develop the app](https://github.com/lwouis/alt-tab-macos/graphs/contributors):

* [adamnemecek](https://github.com/adamnemecek)
* [AfzalivE](https://github.com/AfzalivE)
* [akx](https://github.com/akx)
* [ayroblu](https://github.com/ayroblu)
* [Calinou](https://github.com/Calinou)
* [damonpam](https://github.com/damonpam)
* [decodism](https://github.com/decodism)
* [gcbw](https://github.com/gcbw)
* [gingerr](https://github.com/gingerr)
* [GrzegorzKazana](https://github.com/GrzegorzKazana)
* [hughlilly](https://github.com/hughlilly)
* [i0ntempest](https://github.com/i0ntempest)
* [karbassi](https://github.com/karbassi)
* [L1cardo](https://github.com/L1cardo)
* [lwouis](https://github.com/lwouis)
* [metacodes](https://github.com/metacodes)
* [mnin](https://github.com/mnin)
* [nella17](https://github.com/nella17)
* [notlmn](https://github.com/notlmn)
* [phungtuanhoang1996](https://github.com/phungtuanhoang1996)
* [rbnis](https://github.com/rbnis)
* [Rjevski](https://github.com/Rjevski)
* [ryenus](https://github.com/ryenus)
* [s4na](https://github.com/s4na)
* [samdenty](https://github.com/samdenty)
* [shaqed](https://github.com/shaqed)
* [xanathar](https://github.com/xanathar)
* [zacharee](https://github.com/zacharee)

They helped [localize the app](https://poeditor.com/join/project/8AOEZ0eAZE):

* 73
* Aamirsuleman
* Aarni Koskela
* Abdulelah
* Aden Aziz
* Admin
* afuio@qq. com
* Albert Abdilim
* Ali Gokmen
* Ali. tas103
* Allen Guan
* Ameng
* Anders Brandén
* Anurag Roy
* anushree b
* Arman
* Arthur
* Ash
* blanorama
* bovirus
* caduellery
* Caner İlhan
* Christian Keilmann
* Chun Fei Lung
* Dan
* Dan84
* Darko
* David R
* Davide
* Didier Deschrijver
* EDUARDO
* edu_sombra
* Eliezer Shpigelman
* Eric WANTZ
* Ersagun Kuruca
* Eukarya
* Eyelly wu
* fabifabulousity
* Filipe
* Frangarciasalomon
* Frank
* Friendship1
* Gezimos
* Giang
* Github
* Gkostov
* Grzegorz Kazana
* Guillaume
* hann-solo
* Haoshuai Xu
* Hjörtur Hjartarson
* Hokuto Kato
* Huandngoc
* Ialiendeg
* Indexerrowaty
* isametry
* Isthereanybody
* Jaeyong Sung
* Jakob
* Jakob Licina
* Jakub Bartušek
* jiho4
* Jisan
* Jord Nijhuis
* Jules Beckers
* Julian Nowaczyk
* Julio
* Jungwan Woo
* Kagurazaka Tsuki
* kal
* kant
* Kevinsevinche
* Kim
* Kinyagulovrr
* Klara
* Kushnee5
* Lcwhhh
* Lester
* Loïc 
* LostInCompilation
* Lumaxis
* lwouis
* Maplevantablack
* Marc Pla
* Marekscholle
* Marko McLion
* Martin Mitka
* Martin. mitka
* Martinjnilsen
* Masih
* Max
* Maximilian Falk
* MaximilianFreitag
* Michael
* Milos M
* Mohammad Al Zouabi
* Mr. axel. bock
* MuDraconis
* Muzhenstudent
* Mwolfinspace
* Nathancodes
* Nikola Rajić
* Nils Fahldieck
* Nilton Souza
* Nmolham
* Ori
* Pehovorka
* Peterkim0620
* Petr Kolář
* Philippe Ménendès
* ponchik
* Raphaël
* Rasmus
* Raymonf
* raz
* Razvan
* rbnis
* sawtooth
* Selcuk Dursun
* Seyedparsa Mirtaheri
* Shameem Reza
* SheNeVmerla
* Shivam Bansal
* shlomo
* Spartak
* Stefan
* Svetoslav Stefanov
* test
* Thomas Zander
* Tomoa Nozawa
* Umutakkaya1996
* Vadym
* Vegard
* Vincent Orback
* Vlad
* Webmaster
* Wesley Matos
* Whatsmine-HaoshuaiXu
* Wowpapa3232
* Yamada Keisuke
* Yash
* Yossi Zahn
* ysaito
* Yukai
* yumechan
* Yusuf Caliskan
